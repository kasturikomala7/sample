/* $(function() {
  $("#submit").click(function(event) {
    event.preventDefault();
    $.ajax({
      type: "POST",
      url: "/",
      success: function(data) {
        alert(data);
      },
      error: function(err) {
        alert(err);
      }
    });
  });
}); */