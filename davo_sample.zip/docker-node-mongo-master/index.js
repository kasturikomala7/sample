const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');


var session = require('express-session');

var cookieParser = require('cookie-parser');

var http=require('http');
var path = require('path');



const passport = require("passport");
var loginRouter = require('./routes/login');
const app = express();

var tokenList = [];
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.set('port', process.env.PORT || 3000);

app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({resave: false, saveUninitialized: true, secret: 'secretsession' ,cookie:{maxAge:60000}})); // session secret
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions

app.use(cookieParser());


// Connect to MongoDB
mongoose.connect(
  'mongodb://localhost:27017/items',
  { useNewUrlParser: true }
)
.then(() => console.log('MongoDB Connected'))
.catch(err => console.log(err));

http.createServer(app).listen(app.get('port'), function() {
  console.log('Express server listening on port ' + app.get('port'));
});

app.use('/', loginRouter);


















