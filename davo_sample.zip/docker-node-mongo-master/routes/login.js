var express = require("express");
var router = express.Router();
const fs = require('fs');

const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;

const Item = require('../models/Item');
const jwt = require('jsonwebtoken')

const app = express();


var flash=require("connect-flash");
app.use(flash());
var Authorization = require('./Auth');

//isAuthentication method requires serialized and deserialized
passport.serializeUser(function(Item, done){
    console.log(Item.id,"itemmmid")
    done(null, Item.id);
  });
  
  passport.deserializeUser(function(id, done){
    console.log(id,"idddddddd")
    Item.findById(id, function(err, user){
      console.log(user,"userrrr")
      done(err,user);
    });
  });
  
  //local storage data
  passport.use(new LocalStrategy({
    usernameField : 'name',
    passwordField : 'password',
    passReqToCallback : true,
    session: false
  },
  function(req, name, password, done) {
  Item.findOne({'name':name}, function(err, user) {
        if (err)
            return done(err);
        if (!user)
            return done(null, false, req.flash('loginMessage', 'No user found.'));
  
        if (password != user.password)
            return done(null, false, req.flash('loginMessage', 'Oops! Wrong password.'));
  
        return done(null, user);
    });
  
  }));

  router.get('/', function (req, res, next) {
    res.render('index');
    
  })

 
router.post('/',passport.authenticate('local', {  successRedirect : '/home' ,failureRedirect: '/' }))

 
  router.get('/home',Authorization.isLoggedIn, (req, res) => {
    console.log("nextpagee")
    console.log(req.body,"$$$$$")
    Item.find()
      .then(items => 
        
       {console.log(items,"itemsssssss")
         
        res.render('home',{items})
      }
        )
      .catch(err => res.status(404).json({ msg: 'No items found' }));
    });
    
    router.get('/logout', (req, res) => {
    req.logout();
    console.log(req.isUnauthenticated(),"unauthen")
    res.redirect('/');
    });
    
    router.get('/profile',Authorization.isLoggedIn,(req, res) => {
    Item.find()
      .then( res.render('profile'))
      .catch(err => res.status(404).json({ msg: 'No items found' }));
    });
    
    

 




  module.exports = router;