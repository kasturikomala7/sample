

var Auth={}
Auth.isLoggedIn=isLoggedIn;
module.exports = Auth;


function isLoggedIn(req, res, next){
    console.log("islogged")
    console.log(req.isAuthenticated(),"qqqq")
    if(req.isAuthenticated())
    
     
      return next();
      res.redirect('/');
    }