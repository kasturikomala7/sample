const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;;
const passportLocalMongoose = require("passport-local-mongoose");
const Item = require('./models/Item');
var session = require('express-session');
const jwt = require('jsonwebtoken')

const privatekey = 'my_secret_privatekey'
const publickey = 'my_secret_publickey'
const jwtExpirySeconds = 300

var flash=require("connect-flash");


const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({resave: false, saveUninitialized: true, secret: 'secretsession' })); // session secret
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions
app.use(flash());

// Connect to MongoDB
mongoose.connect(
    'mongodb://localhost:27017/test',
    { useNewUrlParser: true }
  )
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));


//isAuthentication method requires serialized and deserialized
  passport.serializeUser(function(Item, done){
    console.log(Item.id,"itemmmid")
		done(null, Item.id);
	});

	passport.deserializeUser(function(id, done){
    console.log(id,"idddddddd")
		Item.findById(id, function(err, user){
      console.log(user,"userrrr")
			done(err,user);
		});
	});

  //local storage data
  passport.use(new LocalStrategy({
    usernameField : 'name',
    passwordField : 'password',
    passReqToCallback : true,
    session: false
},
function(req, name, password, done) {
  Item.findOne({'name':name}, function(err, user) {
        if (err)
            return done(err);
        if (!user)
            return done(null, false, req.flash('loginMessage', 'No user found.'));

        if (password != user.password)
            return done(null, false, req.flash('loginMessage', 'Oops! Wrong password.'));

        return done(null, user);
    });

}));


app.get('/',(req, res) => {
  Item.find()
    .then(items => res.render('index', {items}))
    .catch(err => res.status(404).json({ msg: 'No items found' }));
});

app.post('/',passport.authenticate('local', {  successRedirect : '/home' ,failureRedirect: '/' }))


/* app.post('/',(req,res) =>{
  console.log(req.body,"body")
  passportmethod
 
}); */

/* function passportmethod(req, res, next){
  return new Promise((resolve,reject)=>{
  resolve  (passport.authenticate('local', {  successRedirect : '/home' ,failureRedirect: '/' }))
})
} */



app.get('/home',isLoggedIn, (req, res) => {
  console.log("nextpagee")
  console.log(req.body,"$$$$$")
  Item.find()
    .then(items => 
      
     {console.log(items,"itemsssssss")
       var token=jwt.sign(userData = { uid:items[0]._id,name: items[0].name },privatekey, {algorithm: 'HS256',expiresIn: jwtExpirySeconds}); //JWT token
      var refreshToken=jwt.sign(userData = { uid:items[0]._id },publickey, {algorithm: 'HS256',expiresIn: jwtExpirySeconds}); //Refresh Token
      res.set("Authorization","Bearer" + token);

      res.render('home',{items,token,refreshToken})
    }
      )
    .catch(err => res.status(404).json({ msg: 'No items found' }));
});

app.get('/logout', (req, res) => {
  req.logout();
  console.log(req.isUnauthenticated(),"unauthen")
  res.redirect('/');
});

app.get('/profile',isLoggedIn,(req, res) => {
  Item.find()
    .then( res.render('profile'))
    .catch(err => res.status(404).json({ msg: 'No items found' }));
});

function isLoggedIn(req, res, next){
  console.log("islogged")
  console.log(req.isAuthenticated(),"qqqq")
	if(req.isAuthenticated())
		return next();

	res.redirect('/');
}


const port = 3000;

app.listen(port, () => console.log('Server running...'));
