const mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');
const Schema = mongoose.Schema;

const ItemSchema = new Schema({
  name: {
    type: String,
    required: true
  },
 password: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  }
});

/* ItemSchema.methods.generateHash = function(password) {
  return bcrypt.hashSync(password, bcrypt.genSaltSync(6), null);
};

ItemSchema.methods.validPassword = function(password) {
  return bcrypt.compareSync(password, this.password);
}; */

module.exports = Item = mongoose.model('item', ItemSchema);
